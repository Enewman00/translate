# translate
A project that translates a phrase from English to many different languages, back to English
