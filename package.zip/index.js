const axios = require("axios");
const {Translate} = require('@google-cloud/translate').v2;


const projectId = 'careful-emitter-358401';
const key='AIzaSyCFw9clTmDeSnnXxhC6WFxJAnVYbhYMf7Y';

// Instantiates a client
//const translate = new Translate(key, {projectId});


exports.handler = async (event) => {
    //var body = event.body;
    
    //translate from English
    var results = await executeTranslate("ja", "Test Message Here!");
    
    
    //const [translation] = await translate.translate("Test Message Here!", "ja");
    //console.log(translation);
    

    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify(results.data.data),
    };
    return response;
};

/*
async function executeTranslate(strSourceText,strApiKey)
{
  var url = `https://translation.googleapis.com/language/translate/v2?key=${key}`
  let response = await fetch(url, {
    method: 'POST',
    headers : { 
      'Content-Type': 'application/json',
     },
     body: JSON.stringify({
       target: "en",
       format: "text",
       q: strSourceText
     }),
  }); 
  let data = await response.json()
  return data;
}
*/

async function executeTranslate(language, phraseToTranslate)
{
    try {
        const response = await axios.post(`https://translation.googleapis.com/language/translate/v2?key=${key}`, { //body
            target: language,
            format: "text",
            q: phraseToTranslate
        }, 
        {
            headers: {
                "Content-Type": "application/json"
            }
        });
        
        return response;
    } catch (error) {
        //console.log(JSON.stringify(error.data));
        throw new Error("Unable to translate: " + error);
    }
}
